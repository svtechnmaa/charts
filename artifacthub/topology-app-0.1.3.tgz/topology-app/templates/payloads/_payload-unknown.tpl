{{- define "payload-unknown" -}}
{
  "edge": {
    "haloColor": "#ffffff",
    "labelCfg": {
      "autoRotate": true,
      "position": "center",
      "style": {
        "background": {
          "padding": [3, 6, 3, 6]
        },
        "fontSize": 14,
        "fontStyle": "bold"
      }
    },
    "style": {
      "endArrow": {
        "fill": "#fa00ff",
        "path": "M 0,0 L 12,-4 L 12,4 Z",
        "stroke": "#fa00ff"
      },
      "lineDash": [],
      "lineWidth": 5,
      "startArrow": {
        "fill": "#fa00ff",
        "path": "M 0,0 L 12,-4 L 12,4 Z",
        "stroke": "#fa00ff"
      },
      "stroke": "#fa00ff",
      "strokeOpacity": 1
    }
  },
  "node": {
    "clipCfg": {
      "r": 30,
      "show": true,
      "type": "circle",
      "x": 0,
      "y": -3
    },
    "haloColor": "#ba00fb",
    "img": "/public/router-big_unknown.svg",
    "labelCfg": {
      "offset": 12,
      "position": "bottom",
      "style": {
        "background": {
          "padding": [3, 6, 3, 6]
        },
        "fillOpacity": 1,
        "fontSize": 14,
        "fontStyle": "bold"
      }
    },
    "size": [45, 30],
    "style": {
      "fillOpacity": 1,
      "lineDash": [],
      "lineWidth": 1,
      "opacity": 1,
      "strokeOpacity": 0.1
    },
    "type": "image"
  }
}
{{- end }}