{{- define "payload-warning" -}}
{
  "edge": {
    "haloColor": "#ff0000",
    "labelCfg": {
      "autoRotate": true,
      "position": "center",
      "style": {
        "background": {
          "padding": [3, 6, 3, 6]
        },
        "fillOpacity": 1,
        "fontSize": 14,
        "fontStyle": "bold",
        "opacity": 1
      }
    },
    "style": {
      "endArrow": {
        "fill": "#fff500",
        "path": "M 0,0 L 12,-4 L 12,4 Z",
        "stroke": "#fff500"
      },
      "lineDash": [],
      "lineWidth": 5,
      "startArrow": {
        "fill": "#fff500",
        "path": "M 0,0 L 12,-4 L 12,4 Z",
        "stroke": "#fff500"
      },
      "stroke": "#fff500",
      "strokeOpacity": 1
    }
  },
  "node": {
    "clipCfg": {
      "r": 30,
      "show": true,
      "type": "circle",
      "x": 0,
      "y": -3
    },
    "haloColor": "#fae106",
    "img": "/public/router-big_warning.svg",
    "labelCfg": {
      "offset": 12,
      "position": "bottom",
      "style": {
        "background": {
          "padding": [3, 6, 3, 6]
        },
        "fillOpacity": 1,
        "fontSize": 14,
        "fontStyle": "bold",
        "opacity": 1
      }
    },
    "size": [45, 30],
    "style": {
      "fillOpacity": 1,
      "lineDash": [],
      "opacity": 1,
      "strokeOpacity": 0.1
    },
    "type": "image"
  }
}
{{- end }}