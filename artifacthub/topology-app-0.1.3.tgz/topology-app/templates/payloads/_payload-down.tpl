{{- define "payload-down" -}}
{
  "edge": {
    "haloColor": "#ff0000",
    "labelCfg": {
      "autoRotate": true,
      "position": "center",
      "style": {
        "background": {
          "padding": [3, 6, 3, 6]
        },
        "fill": "#000000",
        "fontSize": 14,
        "fontStyle": "bold"
      }
    },
    "style": {
      "endArrow": {
        "fill": "#ffffff",
        "path": "M 0,0 L 12,-4 L 12,4 Z",
        "stroke": "#ffffff"
      },
      "lineDash": [],
      "lineWidth": 5,
      "startArrow": false,
      "stroke": "#ffffff"
    }
  },
  "node": {
    "clipCfg": {
      "r": 30,
      "show": true,
      "type": "circle",
      "x": 0,
      "y": -3
    },
    "haloColor": "#000000",
    "img": "/public/router-big_down.svg",
    "labelCfg": {
      "offset": 12,
      "position": "bottom",
      "style": {
        "background": {
          "padding": [3, 6, 3, 6]
        },
        "fillOpacity": 1,
        "fontSize": 14,
        "fontStyle": "bold",
        "opacity": 1
      }
    },
    "size": [45, 30],
    "style": {
      "lineDash": [],
      "lineWidth": 1,
      "strokeOpacity": 0.1
    },
    "type": "image"
  }
}
{{- end }}