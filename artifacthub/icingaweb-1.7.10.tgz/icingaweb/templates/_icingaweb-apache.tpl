---
{{/* Icingaweb apache config */}}
{{- define "icingaweb.icingaweb.apache" }}
# Apache config for icingaweb
Alias /icingaweb "/usr/share/icingaweb2/public/"
# Remove comments if you want to use PHP FPM and your Apache version is older than 2.4
#<IfVersion < 2.4>
#    # Forward PHP requests to FPM
#    SetEnvIf Authorization "(.*)" HTTP_AUTHORIZATION=$1
#    <LocationMatch "^//(.*\.php)$">
#        ProxyPassMatch "fcgi://127.0.0.1:9000//usr/share/icingaweb2/public/$1"
#    </LocationMatch>
#</IfVersion>

<Directory "/usr/share/icingaweb2/public">
    Options SymLinksIfOwnerMatch
    AllowOverride None

    DirectoryIndex index.php

    <IfModule mod_authz_core.c>
        # Apache 2.4
        <RequireAll>
            Require all granted
        </RequireAll>
    </IfModule>

    <IfModule !mod_authz_core.c>
        # Apache 2.2
        Order allow,deny
        Allow from all
    </IfModule>

    SetEnv ICINGAWEB_CONFIGDIR "/etc/icingaweb2"

    EnableSendfile Off

    <IfModule mod_rewrite.c>
        RewriteEngine on
        RewriteBase /icingaweb
        RewriteCond %{REQUEST_FILENAME} -s [OR]
        RewriteCond %{REQUEST_FILENAME} -l [OR]
        RewriteCond %{REQUEST_FILENAME} -d
        RewriteRule ^.*$ - [NC,L]
        RewriteRule ^.*$ index.php [NC,L]
    </IfModule>

    <IfModule !mod_rewrite.c>
        DirectoryIndex error_norewrite.html
        ErrorDocument 404 //error_norewrite.html
    </IfModule>

# Remove comments if you want to use PHP FPM and your Apache version
# is greater than or equal to 2.4
#    <IfVersion >= 2.4>
#        # Forward PHP requests to FPM
#        SetEnvIf Authorization "(.*)" HTTP_AUTHORIZATION=$1
#        <FilesMatch "\.php$">
#            SetHandler "proxy:fcgi://127.0.0.1:9000"
#            ErrorDocument 503 //error_unavailable.html
#        </FilesMatch>
#    </IfVersion>
</Directory>
{{- end }}
