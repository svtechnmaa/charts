{{- define "bngblaster-gui.fullname" -}}
{{- include "common.names.fullname" . -}}
{{- end -}}

{{- define "bngblaster-gui.labels" -}}
{{ include "common.labels.standard" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
{{- end -}}

{{- define "bngblaster-gui.selectorLabels" -}}
{{ include "common.labels.matchLabels" . }}
{{- end -}}

{{- define "bngblaster-gui.image" -}}
{{- $repository := required (printf "%s.image.repository is required" .component) .image.repository -}}
{{- $tag := required (printf "%s.image.tag is required" .component) .image.tag -}}
{{- $global := default dict .root.Values.global -}}
{{- if $global.imageRegistry -}}
{{- printf "%s/%s:%s" ($global.imageRegistry | trimSuffix "/") $repository $tag -}}
{{- else -}}
{{- printf "%s:%s" $repository $tag -}}
{{- end -}}
{{- end -}}

{{- define "bngblaster-gui.backendName" -}}
{{- printf "%s-backend" (include "bngblaster-gui.fullname" .) | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "bngblaster-gui.frontendName" -}}
{{- printf "%s-frontend" (include "bngblaster-gui.fullname" .) | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "bngblaster-gui.databaseHost" -}}
{{- $externalPostgresql := default dict (index .Values "externalPostgresql") -}}
{{- $host := index $externalPostgresql "host" -}}
{{- required "externalPostgresql.host is required" $host -}}
{{- end -}}

{{- define "bngblaster-gui.ingressPath" -}}
{{- $path := default "/" .Values.ingress.path -}}
{{- $stripped := regexReplaceAll "^/+" $path "" -}}
{{- $normalized := trimSuffix "/" (printf "/%s" $stripped) -}}
{{- if eq $normalized "" -}}
/
{{- else -}}
{{- $normalized -}}
{{- end -}}
{{- end -}}

{{- define "bngblaster-gui.backendDataHostPath" -}}
{{- $global := default dict .Values.global -}}
{{- $basePath := default "/opt/shared" $global.basePath | trimSuffix "/" -}}
{{- printf "%s/%s/%s" $basePath .Release.Namespace .Values.sharedVolume.volumeName -}}
{{- end -}}
